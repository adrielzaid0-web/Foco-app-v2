package com.example.foco

import android.app.Activity
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.*

class AppItem(val pkg: String, val name: String, val cat: String, val icon: Drawable)

class MainActivity : Activity() {
    private val BG = Color.parseColor("#0B1020")
    private val CHIP = Color.parseColor("#1A2438")
    private val BORDER = Color.parseColor("#26324D")
    private val MUTED = Color.parseColor("#8B97AD")
    private val GREEN = Color.parseColor("#34D399")
    private val GREEN_D = Color.parseColor("#059669")

    private lateinit var tvTime: TextView
    private lateinit var tvSub: TextView
    private lateinit var badge: TextView
    private lateinit var tvCount: TextView
    private lateinit var permBtn: TextView
    private val extSubs = mutableListOf<TextView>()
    private var all = listOf<AppItem>()
    private val shown = mutableListOf<AppItem>()
    private val blocked = mutableSetOf<String>()
    private lateinit var adapter: AppAdapter

    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() { refresh(); handler.postDelayed(this, 1000) }
    }

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()

    private fun rounded(fill: Int, r: Int, stroke: Int? = null) = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = dp(r).toFloat()
        if (stroke != null) setStroke(dp(1), stroke)
    }

    private fun label(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        blocked.addAll(Prefs.blocked(this))
        loadApps()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BG)
            setPadding(dp(16), dp(12), dp(16), 0)
        }

        // Encabezado
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val lock = TextView(this).apply {
            text = "🔒"; textSize = 18f; gravity = Gravity.CENTER
            background = rounded(Color.parseColor("#2A2415"), 20, Color.parseColor("#4A3B1A"))
        }
        top.addView(lock, LinearLayout.LayoutParams(dp(40), dp(40)))
        val title = label("MODO FOCO", 16f, MUTED, true).apply { letterSpacing = 0.1f; setPadding(dp(12), 0, 0, 0) }
        top.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        badge = label("", 14f, GREEN, true).apply { setPadding(dp(16), dp(8), dp(16), dp(8)) }
        top.addView(badge)
        root.addView(top)

        tvTime = label("00:00:00", 52f, Color.WHITE, true).apply { gravity = Gravity.CENTER }
        root.addView(tvTime, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) })
        tvSub = label("", 15f, MUTED).apply { gravity = Gravity.CENTER }
        root.addView(tvSub, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(16) })

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("+30 MIN" to 30, "+1 H" to 60, "+2 H" to 120).forEach { (t, m) ->
            val btn = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
                setPadding(0, dp(14), 0, dp(14))
                background = rounded(CHIP, 16, BORDER)
                setOnClickListener { Prefs.addMinutes(this@MainActivity, m); refresh() }
            }
            btn.addView(label(t, 18f, GREEN, true))
            val sub = label("Extender", 14f, MUTED)
            extSubs.add(sub)
            btn.addView(sub)
            row.addView(btn, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(4), 0, dp(4), 0) })
        }
        root.addView(row)

        permBtn = label("⚠  Activar permiso de accesibilidad", 15f, Color.parseColor("#FBBF24"), true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(12), dp(16), dp(12))
            background = rounded(Color.parseColor("#2A2415"), 16, Color.parseColor("#4A3B1A"))
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        root.addView(permBtn, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })

        // Sección apps
        val line = View(this).apply { setBackgroundColor(BORDER) }
        root.addView(line, LinearLayout.LayoutParams(-1, dp(1)).apply { topMargin = dp(20); bottomMargin = dp(16) })

        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(label("Apps a bloquear", 20f, Color.WHITE, true), LinearLayout.LayoutParams(0, -2, 1f))
        tvCount = label("", 14f, MUTED).apply {
            setPadding(dp(14), dp(6), dp(14), dp(6))
            background = rounded(CHIP, 20, BORDER)
        }
        head.addView(tvCount)
        root.addView(head)

        val search = EditText(this).apply {
            hint = "🔍  Buscar aplicación..."
            setHintTextColor(MUTED); setTextColor(Color.WHITE); textSize = 16f
            isSingleLine = true
            setPadding(dp(18), dp(12), dp(18), dp(12))
            background = rounded(Color.parseColor("#050814"), 24, BORDER)
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) { filter(s?.toString() ?: "") }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
        }
        root.addView(search, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12); bottomMargin = dp(8) })

        shown.addAll(all)
        adapter = AppAdapter()
        val list = ListView(this).apply {
            divider = null; dividerHeight = 0
            selector = android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)
            isVerticalScrollBarEnabled = false
            this.adapter = this@MainActivity.adapter
        }
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        updateCount()
    }

    private fun loadApps() {
        val pm = packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        all = pm.queryIntentActivities(launcher, 0)
            .filter { it.activityInfo.packageName != packageName }
            .distinctBy { it.activityInfo.packageName }
            .map {
                val pkg = it.activityInfo.packageName
                val cat = try { categoryName(pm.getApplicationInfo(pkg, 0).category) } catch (e: Exception) { "Aplicación" }
                AppItem(pkg, it.loadLabel(pm).toString(), cat, it.loadIcon(pm))
            }
            .sortedBy { it.name.lowercase() }
    }

    private fun categoryName(c: Int) = when (c) {
        ApplicationInfo.CATEGORY_GAME -> "Juegos"
        ApplicationInfo.CATEGORY_AUDIO -> "Música"
        ApplicationInfo.CATEGORY_VIDEO -> "Video"
        ApplicationInfo.CATEGORY_IMAGE -> "Fotos"
        ApplicationInfo.CATEGORY_SOCIAL -> "Social"
        ApplicationInfo.CATEGORY_NEWS -> "Noticias"
        ApplicationInfo.CATEGORY_MAPS -> "Mapas"
        ApplicationInfo.CATEGORY_PRODUCTIVITY -> "Productividad"
        else -> "Aplicación"
    }

    private fun filter(q: String) {
        shown.clear()
        shown.addAll(all.filter { it.name.contains(q.trim(), ignoreCase = true) })
        adapter.notifyDataSetChanged()
    }

    private fun toggle(pkg: String, on: Boolean) {
        if (on) blocked.add(pkg) else blocked.remove(pkg)
        Prefs.setBlocked(this, blocked.toSet())
        updateCount()
    }

    private fun updateCount() { tvCount.text = "${blocked.size} bloqueadas" }

    inner class AppAdapter : BaseAdapter() {
        override fun getCount() = shown.size
        override fun getItem(i: Int) = shown[i]
        override fun getItemId(i: Int) = i.toLong()
        override fun getView(i: Int, v: View?, p: ViewGroup?): View {
            val row = (v as? LinearLayout) ?: buildRow()
            val item = shown[i]
            val icon = row.getChildAt(0) as ImageView
            val col = row.getChildAt(1) as LinearLayout
            val sw = row.getChildAt(2) as Switch
            icon.setImageDrawable(item.icon)
            (col.getChildAt(0) as TextView).text = item.name
            (col.getChildAt(1) as TextView).text = item.cat
            sw.setOnCheckedChangeListener(null)
            sw.isChecked = item.pkg in blocked
            sw.setOnCheckedChangeListener { _, on -> toggle(item.pkg, on) }
            row.setOnClickListener { sw.toggle() }
            return row
        }

        private fun buildRow(): LinearLayout {
            val row = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(4), dp(12), dp(4), dp(12))
            }
            val icon = ImageView(this@MainActivity).apply {
                scaleType = ImageView.ScaleType.FIT_CENTER
                outlineProvider = object : ViewOutlineProvider() {
                    override fun getOutline(view: View, o: Outline) {
                        o.setRoundRect(0, 0, view.width, view.height, dp(14).toFloat())
                    }
                }
                clipToOutline = true
            }
            row.addView(icon, LinearLayout.LayoutParams(dp(52), dp(52)))
            val col = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(16), 0, dp(8), 0)
            }
            col.addView(label("", 17f, Color.WHITE, true))
            col.addView(label("", 14f, MUTED))
            row.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
            val sw = Switch(this@MainActivity).apply {
                val st = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
                thumbTintList = ColorStateList(st, intArrayOf(Color.WHITE, Color.parseColor("#E5E7EB")))
                trackTintList = ColorStateList(st, intArrayOf(GREEN_D, Color.parseColor("#1F2937")))
            }
            row.addView(sw)
            return row
        }
    }

    private fun serviceOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        return s.contains(packageName)
    }

    private fun setBadge(text: String, color: Int, bg: Int) {
        badge.text = text
        badge.setTextColor(color)
        badge.background = rounded(bg, 20, color)
    }

    private fun refresh() {
        val on = serviceOn()
        val left = Prefs.until(this) - System.currentTimeMillis()
        permBtn.visibility = if (on) View.GONE else View.VISIBLE
        if (left > 0) {
            val s = left / 1000
            tvTime.text = "%02d:%02d:%02d".format(s / 3600, s % 3600 / 60, s % 60)
            tvSub.text = "Tiempo restante de bloqueo estricto"
            extSubs.forEach { it.text = "Extender" }
        } else {
            tvTime.text = "00:00:00"
            tvSub.text = "Elige cuánto tiempo bloquear"
            extSubs.forEach { it.text = "Iniciar" }
        }
        when {
            !on -> setBadge("Sin permiso", Color.parseColor("#F87171"), Color.parseColor("#2A1215"))
            left > 0 -> setBadge("Protegido", GREEN, Color.parseColor("#0B2A24"))
            else -> setBadge("Inactivo", MUTED, CHIP)
        }
    }

    override fun onResume() { super.onResume(); handler.post(tick) }
    override fun onPause() { super.onPause(); handler.removeCallbacks(tick) }
}
