package com.example.foco

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast

class BlockerService : AccessibilityService() {
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName) return
        if (Prefs.active(this) && pkg in Prefs.blocked(this)) {
            performGlobalAction(GLOBAL_ACTION_HOME)
            Toast.makeText(this, "Modo foco activo 🔒", Toast.LENGTH_SHORT).show()
        }
    }
    override fun onInterrupt() {}
}
