package com.example.foco

import android.content.Context

object Prefs {
    private fun p(c: Context) = c.getSharedPreferences("foco", Context.MODE_PRIVATE)
    fun blocked(c: Context): Set<String> = p(c).getStringSet("blocked", emptySet())!!.toSet()
    fun setBlocked(c: Context, s: Set<String>) = p(c).edit().putStringSet("blocked", s).apply()
    fun until(c: Context): Long = p(c).getLong("until", 0L)
    fun addMinutes(c: Context, min: Int) {
        val base = maxOf(System.currentTimeMillis(), until(c))
        p(c).edit().putLong("until", base + min * 60_000L).apply()
    }
    fun active(c: Context) = System.currentTimeMillis() < until(c)
}
